//#include "../lib-headers/lib.h"
#include "lib.h"

#include <stdio.h>
#include <stdlib.h>

void println(char s[]);

voidvoid printnl;//print new line

void printls(int n);//print LineS

void printint(int n);

voidvoid limpa;
