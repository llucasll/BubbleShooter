struct{
	struct{
		void *moveu = 
			void moveu(){
			}
		};
		void *clicou = 
			void clicou(){
			}
		};
	}mouse;
}iuf;// Funções para Interface do Usuário

struct{
	
}iuo;// Objetos para Interface do Usuário

struct{
	
}iut;// Tipos para Interface do Usuário

struct{
	
}iuc;// Constantes para Interface do Usuário
