#include "debug.h"

void oi(){
	println("oi");
}
