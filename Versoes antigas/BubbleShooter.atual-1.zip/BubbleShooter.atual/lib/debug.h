#include "lib.h"

#include "terminal.h"

voidvoid oi;

void logger(const char *format, ...);
