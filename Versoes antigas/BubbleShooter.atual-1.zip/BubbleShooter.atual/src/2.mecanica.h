#include "0.cabecalho.h"

bool habitavel(int x, int y);
byte contar(int x, int y);
void matar(int x, int y);
void explodir(int x, int y);
voidvoid descer;
