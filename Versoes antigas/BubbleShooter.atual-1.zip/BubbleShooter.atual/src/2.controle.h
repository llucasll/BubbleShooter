#include "0.cabecalho.h"

voidvoid init;

int preparar(void);

int loadMedia(void);

voidvoid closing;

SDL_Surface* loadSurface( char *path );

//ESSE VEM DO 2.jogo.h
voidvoid execucao;
