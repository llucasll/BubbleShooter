#include "0.cabecalho.h"

voidvoid init;

int preparar(void);

int loadMedia(void);

voidvoid closing;

//ESSE VEM DO 2.jogo.h
voidvoid execucao;
