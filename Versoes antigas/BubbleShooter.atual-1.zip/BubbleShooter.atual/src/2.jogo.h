#include "0.cabecalho.h"

voidvoid execucao;
voidvoid moveNPC;
void createNPC(int x, int y, int velx, int vely);

voidvoid jogoOnClick;
