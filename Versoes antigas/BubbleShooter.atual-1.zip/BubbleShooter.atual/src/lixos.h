
	char ch;
	scanf("%c",&ch);
	printf("%d",ch);
	
*/
