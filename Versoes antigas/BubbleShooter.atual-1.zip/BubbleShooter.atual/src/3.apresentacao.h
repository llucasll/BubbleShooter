#include "0.cabecalho.h"

/* ETAPA DE INICIALIZAÇÃO DO **CONTROLE** */
bool carregarMidia(void);
bool iniciarSDL(void);
voidvoid iniciarInterface;

/* ETAPA DE MECÂNICA */
voidvoid moverSeta;
voidvoid partidaView;
//void atualizar();

/* ETAPA DE FINALIZAÇÃO */
